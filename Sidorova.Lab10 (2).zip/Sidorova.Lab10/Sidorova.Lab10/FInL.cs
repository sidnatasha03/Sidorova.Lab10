﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{

    //класс используется для списков из объектов классов, в которых в качестве поля имеется некоторая строковая переменная ("имя")
    //методы данного класса осуществляют поиск в списке элемента, "имя" которого совпадает с введенной строкой 

    static class FInL
    {
        public static bool Finding1(List<User> L, string s)
        {
            bool BOOL = false;
            foreach (var P in L)
            {
                if (P.Login == s)
                {
                    BOOL = true;
                }
            }
            return BOOL;
        }

        public static bool Finding2(List<Item> L, string s)
        {
            bool BOOL2 = false;
            foreach (var P in L)
            {
                if (P.Name == s)
                {
                    BOOL2 = true;
                }
            }
            return BOOL2;
        }

        public static bool Finding3(List<User> L, string s)
        {
            bool BOOL3 = false;
            foreach (var A in L)
            {
                if (A.AGe >= 18)
                {
                    BOOL3 = true;
                }             
            }
            return BOOL3;
        }
        public static bool Finding4(List<User> L, string s)
        {
            bool BOOL4 = false;
            foreach (var N in L)
            {
                if (N.NUmber_of_phone.StartsWith("+7"));
                {
                    BOOL4 = true;
                }
            }
            return BOOL4;
        }

    }
}
