﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class User       //аккаунт пользователя
    {
        string LOgin;         //логин пользователя
        string PAssword;      //пароль для входа
        int Count;            //внутренний счёт для оплаты
        int Age;
        string Country;
        string Number_of_phone;
        string Email;
        public List<Item> Basket;     //корзина с товарами
        public User(string s1, string s2, string s3, string s4, string s5)    //инициализация происходит при регистрации
        {
            LOgin = s1;
            PAssword = s2;
            Count = 0;
            Age = 0;
            Country = s3;
            Number_of_phone = s4;
            Email = s5;
            Basket = new List<Item>();
        }
        public string Login     //изменение логина в настройках аккаунта и возможность просмотреть логин
        {
            get
            {
                return LOgin;
            }
            set
            {
                LOgin = value;
            }
        }
        public string Password    //изменение пароля в настройках аккаунта и возможность просмотреть пароль
        {
            get
            {
                return PAssword;
            }
            set
            {
                PAssword = value;
            }
        }
        public int MOney             //перечисление денег на счет
        {
            get
            {
                return Count;
            }
            set
            {
                Count = value;
            }
        }

        public string COuntry     
        {
            get
            {
                return Country;
            }
            set
            {
                Country = value;
            }
        }
        public string NUmber_of_phone     
        {
            get
            {
                return Number_of_phone;
            }
            set
            {
                Number_of_phone = value;
            }
        }
        public int AGe             
        {
            get
            {
                return Age;
            }
            set
            {
                Age = value;
            }
        }
        public string EMail
        {
            get
            {
                return Email;
            }
            set
            {
                Email = value;
            }
        }

    }
}