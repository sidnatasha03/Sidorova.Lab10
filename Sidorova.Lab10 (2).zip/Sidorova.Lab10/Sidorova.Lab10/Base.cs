﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{

    public class Base   //внутренняя база данных
    {

        public List<User> L;   //список зарегистрированных пользователей (ключ - логин, значение - пользователь)
        public List<Item> It;  //cписок товаров, имеющихся в наличии
        public User U;         //текущий пользователь

        public Base()   //инициализация списков и определение товаров, имеющихся в наличии изначально

        {
            L = new List<User>();
            It = new List<Item>();
            Item Miniwen = new Item("Минивен", 20000, "Легковые автомобили", 8);
            It.Add(Miniwen);
            Item Pikap = new Item("Пикап", 80000, "Легковые автомобили", 11);
            It.Add(Pikap);
            Item Kabriolet = new Item("Кабриолет", 100000, "Легковые автомобили", 20);
            It.Add(Kabriolet);
            Item Samosval = new Item("Самосвал", 18000, "Грузовые автомобили", 21);
            It.Add(Samosval);
            Item Autocis = new Item("Автоцистерна", 40000, "Грузовые автомобили", 25);
            It.Add(Autocis);
            Item Bunkerovos = new Item("Бункеровоз", 23000, "Грузовые автомобили", 14);
            It.Add(Bunkerovos);
            Item Tur = new Item("Туристический", 30000, "Автобусы", 15);
            It.Add(Tur);
            Item Gorod = new Item("Городские", 33000, "Автобусы", 50);
            It.Add(Gorod);
            Item Prigor = new Item("Пригородские", 20000, "Автобусы", 39);
            It.Add(Prigor);
        }
        public void Current(User U1)   //установка текущего пользователя
        {
            U = U1;
        }
    }
}