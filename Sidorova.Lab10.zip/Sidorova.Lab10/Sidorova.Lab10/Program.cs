﻿using System;
using ClassLibrary1;
using System.Collections.Generic;

namespace Lab10
{

    class Program
    {
        static void Main(string[] args)
        {
            Base B = new Base();
            Menu.InputMenu(B);
        }
    }

}



















